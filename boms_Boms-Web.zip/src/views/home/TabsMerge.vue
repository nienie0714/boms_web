<template>
  <div class="container cross tabs-merge">
    <tabs></tabs>
    <div></div>
  </div>
</template>

<script>
import Tabs from '@view/Tabs/Tabs'

export default {
  components: {
    Tabs
  }
}
</script>

